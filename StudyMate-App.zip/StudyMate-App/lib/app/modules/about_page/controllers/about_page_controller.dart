import 'package:get/get.dart';

class AboutPageController extends GetxController {}
