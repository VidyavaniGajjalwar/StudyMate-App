import 'package:get/get.dart';

class EventPageController extends GetxController {}
