import 'package:get/get.dart';

class IntroController extends GetxController {}
