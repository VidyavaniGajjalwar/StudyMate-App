# Change log

## v1.0.0 - 25 January 2022

Initial Release.
