package com.application.studymate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
